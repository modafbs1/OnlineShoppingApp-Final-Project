package com.moda.ShoppingApp.models

data class CategoryModel(
    var id: String? = "",
    var name: String? = "",
    var imageUrl: String? = ""
)
